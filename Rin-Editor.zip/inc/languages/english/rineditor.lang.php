<?php
$l['rineditor_restore'] = 'Restore';
?>